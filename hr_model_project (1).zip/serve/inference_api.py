
"""FastAPI service for live HR probability."""
from fastapi import FastAPI
import joblib, pandas as pd
from pydantic import BaseModel

app = FastAPI(title="HR Probability API")

model = joblib.load("models/hr_model.pkl")

class PAInput(BaseModel):
    # Provide minimal set of features used at inference time
    launch_speed: float
    launch_angle: float
    stand_R: int
    stand_L: int
    # ... include all one‑hot columns used in training

@app.post("/predict")
def predict(pa: PAInput):
    df = pd.DataFrame([pa.dict()])
    proba = model.predict_proba(df)[:,1][0]
    return {"hr_probability": float(proba)}
