
"""Convert raw Statcast to model‑ready feature set.

Usage:
    python processing/feature_engineering.py raw.parquet features.parquet
"""
import sys, argparse, pathlib, pandas as pd, numpy as np

BASIC_KEEP = [
    "game_date", "batter", "pitcher", "stand", "p_throws",
    "pitch_type", "balls", "strikes", "inning",
    "launch_speed", "launch_angle", "home_team", "away_team",
    "event"
]

def engineer(df: pd.DataFrame) -> pd.DataFrame:
    df = df[BASIC_KEEP].copy()
    df["is_hr"] = (df["event"] == "home_run").astype("int8")
    df["month"] = pd.to_datetime(df["game_date"]).dt.month.astype("int8")
    cat_cols = ["stand", "p_throws", "pitch_type", "home_team", "away_team", "inning", "month"]
    df = pd.get_dummies(df, columns=cat_cols, dummy_na=False)
    return df.drop(columns=["event"])

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("in_path")
    ap.add_argument("out_path")
    args = ap.parse_args()

    df_raw = pd.read_parquet(args.in_path)
    df_feat = engineer(df_raw)
    out = pathlib.Path(args.out_path)
    out.parent.mkdir(exist_ok=True, parents=True)
    df_feat.to_parquet(out, index=False)
    print(f"Features saved to {out} ({df_feat.shape[0]:,} rows, {df_feat.shape[1]} cols)")

if __name__ == "__main__":
    main()
