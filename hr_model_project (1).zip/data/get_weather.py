
"""Utility to fetch historical weather for MLB ballparks.

Requires a Visual Crossing or NWS API key (set VC_API_KEY env var).
"""
import os, requests, pandas as pd

VC = "https://weather.visualcrossing.com/VisualCrossingWebServices/history"

def get_weather(lat, lon, date):
    key = os.getenv("VC_API_KEY")
    params = {
        "key": key,
        "contentType": "json",
        "unitGroup": "us",
        "include": "hours",
        "aggregateHours": 1,
        "location": f"{lat},{lon}",
        "startDateTime": f"{date}T00:00:00",
        "endDateTime": f"{date}T23:59:59",
    }
    r = requests.get(VC, params=params, timeout=30)
    r.raise_for_status()
    return r.json()

# Implement hourly flattening as needed.
